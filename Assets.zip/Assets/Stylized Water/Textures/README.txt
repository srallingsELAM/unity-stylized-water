This demo scene uses the following freely available assets:

CausticsShallow, CausticsDeep
https://www.dualheights.se/caustics/

LargeWaves, SmallWaves, Seafoam, SeaPattern
https://simonschreibt.de/gat/stylized-vfx-in-rime-water-edition/

GentleWaves
http://glowfishinteractive.com/dissolving-the-world-part-1/
