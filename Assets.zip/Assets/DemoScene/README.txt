This demo scene uses the following freely available assets:

Lighthouse Model
https://poly.google.com/view/0t2ZYRBsqX

Blocky Rocks
https://sketchfab.com/3d-models/blocky-rocks-cea1b61f14e34588b33196de72af8983

Low Poly Rocks
https://sketchfab.com/3d-models/low-poly-rocks-9823ec262054408dbe26f6ddb9c0406e

Sand Texture
https://www.deviantart.com/hhh316/art/Seamless-Beach-Sand-Texture-271683282

Dark Sand Texture
https://www.wurmpedia.com/index.php/File:Sand.png